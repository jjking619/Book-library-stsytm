from PySide2 import QtCore,QtGui,QtWidgets,QtUiTools,QtMultimedia
from PySide2.QtCore import QUrl
import sqlite3
import pandas as pd 
import matplotlib.pyplot as plt

class MyWidget(QtWidgets.QWidget): 
    def __init__(self):
       super().__init__()
       
       #初始化数据库
       self.initDatabase()
       self.Playmusic()
       self.login=QtUiTools.QUiLoader().load("login.ui")
       self.login.stackedWidget.setCurrentWidget(self.login.page_login)

    #self.login.resize(1000,1600)
       self.login.pushButton_register.clicked.connect(self.onGoRegisterPage)
       self.login.pushButton_register_return.clicked.connect(self.onBackLoginPage)
       #登录
       self.login.pushButton_register_submit.clicked.connect(self.onRegister)  
       self.login.pushButton_login_submit.clicked.connect(self.onLogin) 


    #初始化数据库
    def initDatabase(self):
         self.con= sqlite3.connect("book.db")    
         self.cursor=self.con.cursor()
         self.cursor.execute("create table if not exists t_user(id char(13) primary key,name varchar(15),passwd varchar(15),phone char(11),role varchar(15));")
         self.cursor.execute("create table if not exists t_book (isbn varchar(13) primary key, title varchar(100), author varchar(60), publisher varchar(100), publishdate varchar(10), number int);")
         self.cursor.execute("CREATE TABLE if not exists t_borrow (user_id varchar(13), book_isbn varchar(13), borrow_date char(10), return_date char(10), PRIMARY KEY(user_id, book_isbn), FOREIGN KEY(user_id) REFERENCES t_user(id), FOREIGN KEY(book_isbn) REFERENCES t_book(isbn));")
    #注册功能实现
    def doRegister(self,id,pwd,name,phone):
      sql=f"insert into t_user values('{id}','{name}','{pwd}','{phone}','普通用户');"
      try:
         self.cursor.execute(sql)
         self.con.commit()
      except sqlite3.Error as e:
          print("insert error",e)
          return False 
      return True
    #登录功能实现
    def doLogin(self,id,pwd):
      sql=f"select id,name,role from t_user where id='{id}' and passwd='{pwd}';"
      self.cursor.execute(sql)
      record=self.cursor.fetchone()
      if record is None:
          return False 
      self.login_user_id=record[0]
      self.login_user_name=record[1]
      self.login_user_role=record[2]
      print(self.login_user_id,self.login_user_name,self.login_user_role)
      return True   
    #播放音乐
    def Playmusic(self):
         self.player = QtMultimedia.QMediaPlayer()
         self.player.setMedia(QtMultimedia.QMediaContent(QUrl.fromLocalFile("岑宁儿 - 追光者.mp3")))
        #  self.player.play()


    #点击登录界面上的注册按钮时跳转到注册界面     
    def onGoRegisterPage(self):
       self.login.stackedWidget.setCurrentWidget(self.login.page_register)
       pass    
    #点击返回按钮返回到登陆界面
    def onBackLoginPage(self):
       self.login.stackedWidget.setCurrentWidget(self.login.page_login)   
       pass
    
    #判断注册
    def onRegister(self):  
       id=self.login.lineEdit_id.text()
       pwd=self.login.lineEdit_pwd.text()
       pwd2=self.login.lineEdit_pwd2.text()
       num=self.login.lineEdit_num.text()
       name=self.login.lineEdit_name.text()
       phone=self.login.lineEdit_phone.text()
      #  print(name,pwd,pwd2,num,grade,tel) 
       if name == "" or pwd =="" or pwd2 =="" or num =="" or id =="" or phone =="" :
           QtWidgets.QMessageBox.warning(self,"警告","用户名不能为空！")
           return
       if pwd !=pwd2 :
          QtWidgets.QMessageBox.warning(self,"警告","两次密码不一致！")
          return
       if self.doRegister(id,pwd,name,phone):
           QtWidgets.QMessageBox.information(self,"提示","注册成功！")
       else:
           QtWidgets.QMessageBox.critical(self,"错误","注册失败！")
   
    #判断登录
    def onLogin(self):
        id=self.login.lineEdit_login_id.text()
        pwd=self.login.lineEdit_login_pwd.text()
        print(id, pwd)
        if id==" " or pwd=="":
            QtWidgets.QMessageBox.warning(self,"警告","登录信息不能为空！")
        if not self.doLogin(id,pwd):
            QtWidgets.QMessageBox.critical(self,"错误","登录失败！")
        else:
            QtWidgets.QMessageBox.information(self,"提示","登录成功！")
            #加载主界面
            self.mainwindow=QtUiTools.QUiLoader().load("mainwindow.ui") 
            self.onGoPageMain()
            self.mainwindow.toolButton_main.clicked.connect(self.onGoPageMain)
            self.mainwindow.toolButton_user.clicked.connect(self.onGoUserPage)
            self.mainwindow.toolButton_book.clicked.connect(self.onGoBookPage)
            self.mainwindow.toolButton_borrow.clicked.connect(self.onGoBorrowPage)
           

            self.mainwindow.pushButton_query_user.clicked.connect(self.onQueryUser)
            self.mainwindow.pushButton_delete_user.clicked.connect(self.onDeleteUser)
            self.mainwindow.pushButton_update_user.clicked.connect(self.onUpdateUser)
            self.mainwindow.pushButton_modify_user.clicked.connect(self.onModifyUser)

            self.mainwindow.pushButton_query_book.clicked.connect(self.onQueryBook)
            self.mainwindow.pushButton_delete_book.clicked.connect(self.onDeleteBook)
            self.mainwindow.pushButton_update_book.clicked.connect(self.onUpdateBook)
            self.mainwindow.pushButton_add_book.clicked.connect(self.onAddBook) 
            self.mainwindow.pushButton_borrow_book.clicked.connect(self.onBorrowBook)   

            self.mainwindow.pushButton_query_borrow.clicked.connect(self.onQueryBorrow)
            self.mainwindow.pushButton_return_borrow.clicked.connect(self.onReturnBorrow)

            #显示主界面
            if(self.login_user_role == "普通用户"):
                self.mainwindow.lineEdit_user.hide()
                self.mainwindow.pushButton_query_user.hide()
                self.mainwindow.pushButton_delete_user.hide()
                self.mainwindow.pushButton_update_user.hide()
            self.mainwindow.show()
            #关闭登录界面
            self.login.close()
    def showLineChart(self):
        borrower_counts = [10, 8, 3, 20, 50]  # Sample borrower counts
        days = ['2023.12.25', '2023.12.26', '2023.12.27', '2023.12.28', '2023.12.29']  # Sample days

        # Set font properties to include Chinese characters
        plt.rcParams['font.sans-serif'] = ['SimHei']  # Use SimHei font for Chinese characters
        plt.rcParams['axes.unicode_minus'] = False  # Ensure that minus signs are displayed correctly

        fig, ax = plt.subplots(figsize=(8, 5))  # Adjust the figure size as needed

        # Plot the data with improved aesthetics
        ax.plot(days, borrower_counts, marker='o', color='b', linestyle='-', linewidth=2, markersize=8)

        # Title and axis labels with adjusted font size
        ax.set_title('图书借阅情况', fontsize=16, fontweight='bold')
        ax.set_xlabel('时间', fontsize=14, fontweight='bold')
        ax.set_ylabel('借阅人数', fontsize=14, fontweight='bold')


        ax.grid(True, linestyle='--', alpha=0.5)
        ax.legend(loc='upper left',fontsize=12)
        for i,txt in enumerate(borrower_counts):
            ax.annotate(txt,(days[i],borrower_counts[i]),textcoords="offset points",xytext=(0,10),ha='center',fontsize=10)
        plt.tight_layout()

        plt.savefig('charts.jpg') 
        plt.close()  

        chart_label = self.mainwindow.findChild(QtWidgets.QLabel, "label") 
        if chart_label:
            chart_label.setPixmap(QtGui.QPixmap('charts.jpg'))
            chart_label.setScaledContents(True)
        else:
            print("Could not find QLabel named 'label'")


    #跳转到主界面
    def onGoPageMain(self): 
      self.showLineChart()
      self.mainwindow.stackedWidget.setCurrentWidget(self.mainwindow.page_main)
            
    #跳转到user界面
    def onGoUserPage(self):
        self.mainwindow.stackedWidget.setCurrentWidget(self.mainwindow.page_user)
    
    #跳转到book界面
    def onGoBookPage(self):
            self.mainwindow.stackedWidget.setCurrentWidget(self.mainwindow.page_book)
    
    #跳转到borrow界面        
    def onGoBorrowPage(self):
            self.mainwindow.stackedWidget.setCurrentWidget(self.mainwindow.page_borrow)
   
    #查询功能
    def onQueryUser(self):
        condition = self.mainwindow.lineEdit_user.text()
        sql = f"select id, name, passwd, phone, role from t_user where id like '%{condition}%'"
        self.cursor.execute(sql)
        model = QtGui.QStandardItemModel()
        model.setHorizontalHeaderLabels(['学号', '姓名', '密码', '手机', '身份'])
        result_set = self.cursor.fetchall()
        for i in range(len(result_set)):
            for j in range(5):
                item = QtGui.QStandardItem(result_set[i][j])
                item.setTextAlignment(QtCore.Qt.AlignCenter)
                model.setItem(i, j, item)
        self.mainwindow.tableView_user.setModel(model)
    
    #删除功能 
    def onDeleteUser(self):

        row=self.mainwindow.tableView_user.currentIndex().row()
        if row == -1:
          return
        model=self.mainwindow.tableView_user.model()
        id=model.item(row,0).text()
        print(row,id)
        r=QtWidgets.QMessageBox.question(self,"删除",f"是否要删除{id}这条记录?")
        print(r)
        if r is QtWidgets.QMessageBox.StandardButton.No:
            return
        sql= f"delete from t_user where id='{id}';"
        self.cursor.execute(sql)
        self.con.commit()
        if self.cursor.rowcount ==1:
            QtWidgets.QMessageBox.information(self,"提示","删除成功！")
        self.onQueryUser()
    #修改密码功能
    def onModifyUser(self):    
        # 获取数据
        row=self.mainwindow.tableView_user.currentIndex().row()
        if row == -1:
          return
        model=self.mainwindow.tableView_user.model()
        id=model.item(row,0).text()
        name=model.item(row,1).text()
        pwd=model.item(row,2).text()
        #加载界面
        self.modifyuser=QtUiTools.QUiLoader().load("modifyuser.ui")
        self.modifyuser.pushButton_submit.clicked.connect(self.onSubmitModifyUser)
         #修改信息
        self.modifyuser.lineEdit_id.setText(id)
        self.modifyuser.lineEdit_name.setText(name)
        self.modifyuser.lineEdit_pwd.setText(pwd)
        #显示界面
        self.modifyuser.show()
    #提交修改密码信息
    def onSubmitModifyUser(self):
          #获取数据
        id=self.modifyuser.lineEdit_id.text()
        name=self.modifyuser.lineEdit_name.text()
        newpwd=self.modifyuser.lineEdit_newpwd.text()
        sql = f"update t_user set name='{name}', passwd='{newpwd}'where id='{id}';"
        #执行sql
        self.cursor.execute(sql)
        self.con.commit()
        if self.cursor.rowcount ==1:
            QtWidgets.QMessageBox.information(self,"提示","修改密码成功！")
        else:
            QtWidgets.QMessageBox.critical(self,"错误","修改密码失败！")
        self.onQueryUser()
    
    #修改功能    
    def onUpdateUser(self):
        row=self.mainwindow.tableView_user.currentIndex().row()
        if row == -1:
          return
        model=self.mainwindow.tableView_user.model()
        id=model.item(row,0).text()
        name=model.item(row,1).text()
        pwd=model.item(row,2).text()
        phone=model.item(row,3).text()
        role=model.item(row,4).text()
        #加载界面
        self.updateuser=QtUiTools.QUiLoader().load("updateuser.ui")
        self.updateuser.pushButton_submit.clicked.connect(self.onSubmitUpdateuser)
        #修改信息
        self.updateuser.lineEdit_id.setText(id)
        self.updateuser.lineEdit_name.setText(name)
        self.updateuser.lineEdit_pwd.setText(pwd)
        self.updateuser.lineEdit_phone.setText(phone)
        self.updateuser.comboBox_role.setCurrentText(role)
        #显示界面
        self.updateuser.show()
    #提交修改用户信息
    def onSubmitUpdateuser(self):
        #获取数据
        id=self.updateuser.lineEdit_id.text()
        name=self.updateuser.lineEdit_name.text()
        pwd=self.updateuser.lineEdit_pwd.text()
        phone=self.updateuser.lineEdit_phone.text()
        role=self.updateuser.comboBox_role.currentText()
        sql = f"update t_user set name='{name}', passwd='{pwd}', phone='{phone}', role='{role}' where id='{id}';"
        #执行sql
        self.cursor.execute(sql)
        self.con.commit()
        if self.cursor.rowcount ==1:
            QtWidgets.QMessageBox.information(self,"提示","修改成功！")
        else:
            QtWidgets.QMessageBox.critical(self,"错误","修改失败！")
   
    #查书
    def onQueryBook(self):
        condition = self.mainwindow.lineEdit_book.text()
        sql = f"select isbn,title, author, publisher, publishdate,number from t_book where title like '%{condition}%'"
        self.cursor.execute(sql)
        model = QtGui.QStandardItemModel()
        model.setHorizontalHeaderLabels(['书号', '姓名', '作者', '出版社', '出版时间','数量'])
        result_set = self.cursor.fetchall()
        for i in range(len(result_set)):
            for j in range(6):
                item = QtGui.QStandardItem(str(result_set[i][j]))
                item.setTextAlignment(QtCore.Qt.AlignCenter)
                model.setItem(i, j, item)
        self.mainwindow.tableView_book.setModel(model)  
    #删书   
    def onDeleteBook(self):
        row=self.mainwindow.tableView_book.currentIndex().row()
        if row == -1:
          return
        model=self.mainwindow.tableView_book.model()
        isbn=model.item(row,0).text()
        print(row,isbn)
        r=QtWidgets.QMessageBox.question(self,"删除",f"是否要删除{isbn}这条记录?")
        print(r)
        if r is QtWidgets.QMessageBox.StandardButton.No:
            return
        sql= f"delete from t_book where isbn='{isbn}';"
        self.cursor.execute(sql)
        self.con.commit()
        if self.cursor.rowcount ==1:
            QtWidgets.QMessageBox.information(self,"提示","删除成功！")
    #修改书籍信息
    def onUpdateBook(self):
        row=self.mainwindow.tableView_book.currentIndex().row()
        if row == -1:
          return
        model=self.mainwindow.tableView_book.model()
        isbn=model.item(row,0).text()
        title=model.item(row,1).text()
        author=model.item(row,2).text()
        publish=model.item(row,3).text()
        publishdate=model.item(row,4).text()
        number=model.item(row,5).text()
        #加载界面
        self.updatebook=QtUiTools.QUiLoader().load("updatebook.ui")
        self.updatebook.pushButton_submit.clicked.connect(self.onSubmitUpdatebook)
        #修改信息
        self.updatebook.lineEdit_isbn.setText(isbn)
        self.updatebook.lineEdit_title.setText(title)
        self.updatebook.lineEdit_author.setText(author)
        self.updatebook.lineEdit_pub.setText(publish)
        self.updatebook.lineEdit_pubdate.setText(publishdate)
        self.updatebook.lineEdit_number.setText(number)
        #显示界面
        self.updatebook.show()
    #提交修改的书籍信息
    def onSubmitUpdatebook(self):
        isbn=self.updatebook.lineEdit_isbn.text()
        title=self.updatebook.lineEdit_title.text()
        author=self.updatebook.lineEdit_author.text()
        publish=self.updatebook.lineEdit_pub.text()
        publishdate=self.updatebook.lineEdit_pubdate.text()
        number=self.updatebook.lineEdit_number.text()
        sql = f"update t_book set title='{title}', author='{author}', publisher='{publish}',publishdate='{publishdate}',number='{number}' where isbn='{isbn}';"
        #执行sql
        self.cursor.execute(sql)
        self.con.commit()
        if self.cursor.rowcount ==1:
            QtWidgets.QMessageBox.information(self,"提示","修改成功！")
        else:
            QtWidgets.QMessageBox.critical(self,"错误","修改失败！")
        self.onQueryUser()
    #添加书
    def onAddBook(self):
        # Open a file dialog to select the file
        file_dialog = QtWidgets.QFileDialog()
        file_path, _ = file_dialog.getOpenFileName(None, "选择文件", "", "Excel Files (*.xlsx *.xls);;All Files (*)")

        if file_path:
            # Pass the file path to onSubmitAddBook
            self.onSubmitAddBook(file_path)

    def onSubmitAddBook(self, file_path):
        try:
            # Read the Excel file using pandas
            df = pd.read_excel(file_path)

            for index, row in df.iterrows():
                isbn = str(row['isbn'])
                title = str(row['title'])
                author = str(row['author'])
                publisher = str(row['publisher'])
                publishdate = str(row['publishdate'])
                number = int(row['number'])

                # Check if ISBN already exists
                sql_check = "SELECT * FROM t_book WHERE isbn=?"
                self.cursor.execute(sql_check, (isbn,))
                if self.cursor.fetchone() is not None:
                    QtWidgets.QMessageBox.warning(None, "警告", f"书籍已存在：ISBN {isbn}")
                    continue

                # Insert the new book
                sql_insert = "INSERT INTO t_book (isbn, title, author, publisher, publishdate, number) VALUES (?, ?, ?, ?, ?, ?)"
                self.cursor.execute(sql_insert, (isbn, title, author, publisher, publishdate, number))

            # Commit the changes
            self.con.commit()

            QtWidgets.QMessageBox.information(None, "提示", "批量导入成功！")
        except Exception as e:
            QtWidgets.QMessageBox.critical(None, "错误", f"批量导入失败：{str(e)}")
    #查询书籍 
    def onQueryBorrow(self):
        sql=f"select id,name,isbn,title,borrow_date,return_date from t_borrow join t_user on user_id=id join t_book on book_isbn=isbn;"   
        self.cursor.execute(sql)
        model = QtGui.QStandardItemModel()
        model.setHorizontalHeaderLabels(['用户号', '姓名', '序列号', '书名', '借书时间','还书时间'])
        result_set=self.cursor.fetchall()
        for i in range(len(result_set)):
            for j in range(6):
                item = QtGui.QStandardItem(str(result_set[i][j]))
                item.setTextAlignment(QtCore.Qt.AlignCenter)
                model.setItem(i, j, item)
        self.mainwindow.tableView_borrow.setModel(model)     
    #借阅书籍
    def onBorrowBook(self):
        selected_rows = set(index.row() for index in self.mainwindow.tableView_book.selectionModel().selectedRows())
        if not selected_rows:
            return
        model = self.mainwindow.tableView_book.model()
        borrow_date = QtCore.QDate.currentDate().toString("yyyy/MM/dd")
        success_count = 0
        failure_count = 0
        failure_messages = []
        for row in selected_rows:
            isbn = model.item(row, 0).text()
            sql_check_borrowed = f"SELECT * FROM t_borrow WHERE user_id='{self.login_user_id}' AND book_isbn='{isbn}' AND return_date IS NOT NULL;"
            self.cursor.execute(sql_check_borrowed)
            returned_record = self.cursor.fetchone()
            if returned_record is not None:
                update_sql = f"UPDATE t_borrow SET borrow_date='{borrow_date}', return_date=NULL WHERE user_id='{self.login_user_id}' AND book_isbn='{isbn}';"
                update_number = f"UPDATE t_book SET number=number-1 WHERE isbn='{isbn}' ;"
                try:
                    self.cursor.execute(update_sql)
                    self.cursor.execute(update_number)
                    success_count += 1
                except sqlite3.Error as e:
                    failure_count += 1
                    failure_messages.append(f"更新借阅记录失败（ISBN: {isbn}）: {str(e)}")
            else:
                sql_check_borrowed = f"SELECT * FROM t_borrow WHERE user_id='{self.login_user_id}' AND book_isbn='{isbn}' AND return_date IS NULL;"
                self.cursor.execute(sql_check_borrowed)
                existing_borrowing = self.cursor.fetchone()
                if existing_borrowing is None:
                    sql_borrow = f"INSERT INTO t_borrow(user_id, book_isbn, borrow_date, return_date) VALUES ('{self.login_user_id}', '{isbn}', '{borrow_date}', '');"
                    try:
                        self.cursor.execute(sql_borrow)
                        update_sql1 = f"UPDATE t_book SET number=number-1 WHERE isbn='{isbn}' AND number > 0;"
                        self.cursor.execute(update_sql1)
                        success_count += 1
                    except sqlite3.Error as e:
                        failure_count += 1
                        failure_messages.append(f"借阅失败（ISBN: {isbn}）: {str(e)}")
                else:
                    failure_count += 1
                    failure_messages.append(f"您已借阅过该书，无法重复借阅（ISBN: {isbn}）")
        self.con.commit()
        if success_count > 0:
            success_message = f"成功借阅 {success_count} 本书。"
            QtWidgets.QMessageBox.information(self, "提示", success_message)
        if failure_count > 0:
            failure_message = "部分借阅失败，详情如下:\n\n" + '\n'.join(failure_messages)
            QtWidgets.QMessageBox.warning(self, "警告", failure_message)
        self.onQueryBorrow()
    #还书
    def onReturnBorrow(self):
        selected_rows = set(index.row() for index in self.mainwindow.tableView_borrow.selectionModel().selectedRows())
        if not selected_rows:
            return
        model = self.mainwindow.tableView_borrow.model()
        return_date = QtCore.QDate.currentDate().toString("yyyy/MM/dd")
        for row in selected_rows:
            user_id = model.item(row, 0).text()
            isbn = model.item(row, 2).text()
            return_borrowed=f"SELECT * FROM t_borrow WHERE user_id='{self.login_user_id}' AND book_isbn='{isbn}' AND return_date is NULL;"
            self.cursor.execute(return_borrowed)
            sql_update = f"UPDATE t_borrow SET return_date='{return_date}' WHERE user_id={user_id} AND book_isbn='{isbn}' ;"
            self.cursor.execute(sql_update)
            sql_number = f"UPDATE t_book SET number=number+1 WHERE isbn='{isbn}';"
            self.cursor.execute(sql_number)
            self.onQueryBorrow()
            self.con.commit()
            QtWidgets.QMessageBox.information(self, "提示", "归还成功！")
        self.onQueryBorrow()

if __name__ =="__main__":
  app=QtWidgets.QApplication([])
  #实例化一个空白界面对象
  w=MyWidget()
  w.login.show()
  app.exec_()

#重新借数量不更新，且连续点击还书按钮
#c:\users\86155\appdata\local\programs\python\python39\lib\site-packages\pyside2\designer.exe